exports.organization = 'apigee-certify'
exports.application = 'exam-06'
exports.userName = 'examuser'
exports.password = 'uGyF3ukQ1i1'
exports.tokenExpiration = 60000
exports.logging = true
exports.uri = 'https://apigee-edu-prod.apigee.net/appservices/'
